function stringlength(){
    var name=$("#firstName").val();
    alert("User name is:"+name.length);
}